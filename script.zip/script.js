let billboards=[
['MG Road Digital',15000],
['Airport LED',22000],
['UB City Premium',35000]
];

let selectedBoard='';
let totalAmount=0;

let html='';

billboards.forEach(b=>{

html+=`
<div class='card'>
<h2>${b[0]}</h2>

<p>₹${b[1]}/week</p>

<button onclick="bookSlot('${b[0]}')">
Book Slot
</button>

</div>
`;

});


document.addEventListener(
'DOMContentLoaded',
()=>{
boards.innerHTML=html;
}
);



function toggleMenu(){

menuBox.style.display=
menuBox.style.display=="block"
? "none"
: "block";

}



function hideAll(){
document.querySelectorAll(
'section'
).forEach(
x=>x.classList.remove('active')
);
}



function goHome(){
hideAll();
home.classList.add('active');
}

function goBooking(){
hideAll();
booking.classList.add('active');
}

function goMap(){
hideAll();
mapview.classList.add('active');
}

function goOrders(){

hideAll();

orders.classList.add('active');

loadCharts();

}



function bookSlot(board){

selectedBoard=board;

hideAll();

bookingForm.classList.add('active');

}



/* FIXED PAYMENT BUTTON */

function goPaymentPage(){

let product=
document.getElementById(
'productName'
).value;

let numWeeks=
parseInt(
document.getElementById(
'weeks'
).value
);


if(!product || !numWeeks){

alert(
"Please fill all details"
);

return;

}


let b=
billboards.find(
x=>x[0]==selectedBoard
);

totalAmount=
b[1]*numWeeks;


hideAll();

paymentPage.classList.add('active');

}



function showUPI(){

paymentContent.innerHTML=`

<div class='card'>

<h2>UPI QR</h2>

<h3>₹${totalAmount}</h3>

<div style='font-size:120px'>
▓▓░▓▓
</div>

<button onclick="confirmPayment()">
Confirm Payment
</button>

</div>

`;

}



function showCard(type){

paymentContent.innerHTML=`

<div class='card'>

<h2>${type}</h2>

<input placeholder='Card Number'>
<input placeholder='Name'>

<button onclick="confirmPayment()">
Pay ₹${totalAmount}
</button>

</div>

`;

}



function confirmPayment(){

hideAll();

confirmPage.classList.add('active');

confirmDetails.innerHTML=
`
Board:
${selectedBoard}
<br>
Amount:
₹${totalAmount}
`;

}



function searchProduct(){

googleMap.src=
"https://www.google.com/maps?q=MG+Road+Bangalore&output=embed";

mapResult.innerHTML=
"<div class='card'>Hotspots Updated</div>";

}



function showHotspot(zone){

alert(
zone+
"\nROI 24%"
);

}



function loadCharts(){

new Chart(
trafficChart,
{
type:'bar',
data:{
labels:['10','1','4','7'],
datasets:[{
data:[5,9,15,22]
}]
}
}
);


new Chart(
viewChart,
{
type:'line',
data:{
labels:[
'Mon',
'Tue',
'Wed',
'Thu'
],
datasets:[{
data:[
42,
47,
52,
60
]
}]
}
}
);

}